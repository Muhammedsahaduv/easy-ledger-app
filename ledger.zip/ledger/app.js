let transactions = [];
let balance = 0;

function addTransaction() {
    const productInput = document.getElementById('product');
    const descriptionInput = document.getElementById('description');
    const amountInput = document.getElementById('amount');
    const product = productInput.value.trim();
    const description = descriptionInput.value.trim();
    const amount = parseFloat(amountInput.value);

    if (!product || !description || isNaN(amount)) {
        alert('Please enter valid product, description, and amount.');
        return;
    }

    transactions.push({ product, description, amount });
    updateUI();

    productInput.value = '';
    descriptionInput.value = '';
    amountInput.value = '';
}

function updateUI() {
    const transactionList = document.getElementById('transactionList');
    transactionList.innerHTML = '';
    
    transactions.forEach(transaction => {
        const li = document.createElement('li');
        li.textContent = `${transaction.product} - ${transaction.description}: ${transaction.amount.toFixed(2)}`;
        transactionList.appendChild(li);
    });

    balance = transactions.reduce((acc, transaction) => acc + transaction.amount, 0);
    document.getElementById('balance').textContent = balance.toFixed(2);
}

function saveToFile() {
    const fileContent = transactions.map(t => `${t.product}, ${t.description}, ${t.amount}`).join('\n');
    const blob = new Blob([fileContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'transactions.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}
